I implemented this in python 3 using the following libraries
pandas, numpy, sys, and deepcopy. I ran the program on a windows computer with
ubuntu for windows executing the program. There are two files for this program
main.py and kmeans.py:

main.py is where the data is imported and Kmeans class is called

kmeans.py is where the kmeans class is and where the helper functions for that class are

To run the program use:
      python3 main.py 2 input1.txt
2 is the K value
input1.txt is the name of the file to be imported
